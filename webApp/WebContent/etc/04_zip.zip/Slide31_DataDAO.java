import java.util.ArrayList;
import java.util.List;

public class Slide31_DataDAO extends DBConn{
	
	public Slide31_DataDAO() {}
	public List<Slide31_DataVO> getSearchRecord(String searchWord){
		List<Slide31_DataVO> lst = new ArrayList<Slide31_DataVO>();
		try {
			getConn();

			sql = "select room_code, title, addr, reserv_start, reserv_finish, cost "
					+ " from roomtbl where title like ? or addr like ? or to_char(reserv_start,'YYYY-MM-DD') like ? order by room_code";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + searchWord + "%");
			pstmt.setString(2, "%" + searchWord + "%");
			pstmt.setString(3, "%" + searchWord + "%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Slide31_DataVO vo = new Slide31_DataVO();
				vo.setRoom_code(rs.getInt(1));
				vo.setTitle(rs.getString(2));
				vo.setAddr(rs.getString(3));
				vo.setReserv_start(rs.getString(4));
				vo.setReserv_finish(rs.getString(5));
				vo.setCost(rs.getInt(6));
				lst.add(vo);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbClose();
		}
		return lst;
	}
	
	public List<Slide31_DataVO> roomAllSelect(){
		List<Slide31_DataVO> lst = new ArrayList<Slide31_DataVO>();
		try {
			getConn();
			sql = "select room_code, title, addr, reserv_start, reserv_finish, cost "
					+ " from roomtbl";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Slide31_DataVO vo = new Slide31_DataVO(rs.getInt(1), rs.getString(2), rs.getString(3), 
						rs.getString(4), rs.getString(5), rs.getInt(6));
				lst.add(vo);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbClose();
		}
		return lst;
	}
	public List<Slide31_DataVO> getmainSearch(String searchArea, String searchDate){
		List<Slide31_DataVO> lst = new ArrayList<Slide31_DataVO>();
		try {
			getConn();

			sql = "select room_code, title, addr, reserv_start, reserv_finish, cost "
					+ " from roomtbl where addr like ? or to_char(reserv_start,'YYYY/MM/DD') like ? order by room_code";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + searchArea + "%");
			pstmt.setString(2, "%" + searchDate + "%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Slide31_DataVO vo = new Slide31_DataVO();
				vo.setRoom_code(rs.getInt(1));
				vo.setTitle(rs.getString(2));
				vo.setAddr(rs.getString(3));
				vo.setReserv_start(rs.getString(4));
				vo.setReserv_finish(rs.getString(5));
				vo.setCost(rs.getInt(6));
				lst.add(vo);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbClose();
		}
		return lst;
	}
	
	

}
