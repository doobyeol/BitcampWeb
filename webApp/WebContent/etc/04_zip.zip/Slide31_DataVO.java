
public class Slide31_DataVO {
	
	private String title;
	private String addr;
	private int room_code;
	private String reserv_start; 
	private String reserv_finish; 
	private int cost; 
	
	public Slide31_DataVO() {
		
	}
	
	public Slide31_DataVO(int room_code, String title, String addr, String reserv_start, String reserv_finish, int cost) {
		this.room_code = room_code;
		this.title = title;
		this.addr = addr;
		this.reserv_start = reserv_start;
		this.reserv_finish = reserv_finish;
		this.cost = cost;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public int getRoom_code() {
		return room_code;
	}

	public void setRoom_code(int room_code) {
		this.room_code = room_code;
	}

	public String getReserv_start() {
		return reserv_start;
	}

	public void setReserv_start(String reserv_start) {
		this.reserv_start = reserv_start;
	}

	public String getReserv_finish() {
		return reserv_finish;
	}

	public void setReserv_finish(String reserv_finish) {
		this.reserv_finish = reserv_finish;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}
	

}
