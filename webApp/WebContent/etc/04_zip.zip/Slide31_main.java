import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.AbstractCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

public class Slide31_main extends JPanel implements ActionListener {
	/*
	 * mainPane 말고
	 * serarchMainPane으로 출력하셔야 합니다!!!!
	 * 
	 * mainPane하면 크기가 이상해요!
	 * 
	 * 
	 * 
	 */
	JPanel mainPane = new JPanel();
		JPanel searchMainPane = new JPanel(new BorderLayout());
			JPanel searchBar = new JPanel(new BorderLayout());
				JTextField searchTextField = new JTextField("");
				JButton searchBtn = new JButton("조회");
			JPanel topSearchPane = new JPanel(new BorderLayout());
				JPanel backBar = new JPanel(new BorderLayout());
					JButton backBtn = new JButton("◀이전페이지");
				
				//
				String searchResultTitle[] = {"회의실코드", "제목", "주소", "예약시작시간", "예약종료시간", "비용", "조회하기"};
				DefaultTableModel searchResultModel = new DefaultTableModel(searchResultTitle,0);
				JTable searchResultTable = new JTable(searchResultModel);
				JScrollPane searchResultScrollPane = new JScrollPane(searchResultTable);
	
	ImageIcon checkIcon = new ImageIcon("img/checkIcon.PNG");
	JButton checkBtn = null;
				
	Common common = new Common();
	int row = 0;
	int col = 0;
	String mainDate, mainArea;
	
	
	public Slide31_main() { }
	
	public JPanel Slide32_mainPanel(JFrame f) {
		searchMainPane.setPreferredSize(new Dimension(950,750));
		
			mainPane.add(searchMainPane);
				searchMainPane.add("North",searchBar);
					searchBar.add(searchTextField);
					searchBar.add("East",searchBtn);
				searchMainPane.add(topSearchPane);
					topSearchPane.add("North",backBar);
						backBar.add("West", backBtn);
					topSearchPane.add(searchResultScrollPane);
					
					
			common.setPanel(mainPane);
			common.setPanel(searchMainPane);
			common.setButton(searchBtn);
			common.setPanel(topSearchPane);
			common.setPanel(backBar);
			common.setButton(backBtn);
			common.setTable(searchResultTable);
			
		setSize(); // 테이블 너비 조절하는 부분
					
		searchResultTable.addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent me) {
				if(me.getButton() == 1) {
					row = searchResultTable.getSelectedRow();
					col = searchResultTable.getSelectedColumn();
					if(col == 6) {
						getSelectedTable(row);
						// 버튼 누르면 회의실 번호 출력해주는 부분
					}
				}
			}
		});
		getMemberAll();	//모든 회의실 목록 출력해주는 메소드
		
		
		searchBtn.addActionListener(this);
		backBtn.addActionListener(this);
		searchTextField.addActionListener(this);
		return mainPane;	// 메인에 추가하기 위해서 리턴해줌
	}
	
	public void getSelectedTable(int selectrow) { 		// 테이블에서 조회버튼을 클릭한 회의실 코드를 받는 메소드
		String select = searchResultTable.getValueAt(selectrow, 0).toString();
		System.out.println("선택한 회의실 코드는 "+ select + "입니다.\n이제 여기서 회의실 조회로 넘어가야 합니다");	// select 가 클릭한 회의실의 번호입니다
	}
	
	public void setSize() {
		// 아래쪽 테이블 추가분
		searchResultTable.getColumnModel().getColumn(0).setPreferredWidth(10);
		searchResultTable.getColumnModel().getColumn(1).setPreferredWidth(170);
		searchResultTable.getColumnModel().getColumn(2).setPreferredWidth(170);
		searchResultTable.getColumnModel().getColumn(3).setPreferredWidth(60);
		searchResultTable.getColumnModel().getColumn(4).setPreferredWidth(60);
		searchResultTable.getColumnModel().getColumn(5).setPreferredWidth(25);
		searchResultTable.getColumnModel().getColumn(6).setPreferredWidth(15);
		searchResultTable.getColumnModel().getColumn(6).setCellRenderer(new TableButton(checkBtn,checkIcon));
		searchResultTable.getColumnModel().getColumn(6).setCellEditor(new TableButton(checkBtn,checkIcon));
	}
	
	class TableButton extends AbstractCellEditor implements TableCellEditor, TableCellRenderer, ActionListener {
		JButton btn;
		public TableButton() {}
		public TableButton(JButton btn, ImageIcon icon) {
			this.btn = new JButton(icon);
			common.setButton(this.btn);

			this.btn.addActionListener(this);
		}

		public void actionPerformed(ActionEvent ae) {
			String str = ae.getSource().toString();
			if(str.indexOf("checkIcon")>0) {
			}
			
		}

		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			return this.btn;
		}

		public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
				int column) {
			return this.btn;
		}
		public Object getCellEditorValue() {
			return null;
		}
		
	}
	
	public void getMemberAll() {	// 모든 회의실 출력
		Slide31_DataDAO dao = new Slide31_DataDAO();
		List<Slide31_DataVO> lst = dao.roomAllSelect();
		
		setNewTableList(lst);
	}
	
	public void mainSearch() {		// 메인에서 입력받은 값 결과 출력, 메인에서 올때만 받을 예정
		Slide31_DataDAO dao = new Slide31_DataDAO();
		List<Slide31_DataVO> lst = dao.getmainSearch(mainArea, mainDate);
		
		setNewTableList(lst);
	}

	public void memberSearch() {	// 검색한 주소, 제목, 날짜(yyyy-mm-dd)으로 결과가 나옴
		String searchWord = searchTextField.getText();
		if(searchWord.equals("")) {
			JOptionPane.showMessageDialog(this, "검색어를 입력해주세요");
		}else {
			Slide31_DataDAO dao = new Slide31_DataDAO();
			List<Slide31_DataVO> searchList = dao.getSearchRecord(searchWord);
			if(searchList.size() == 0) {
				JOptionPane.showMessageDialog(this, "없음!");
			}else {
				setNewTableList(searchList);
			}
		}
	}
		
	public void setNewTableList(List<Slide31_DataVO> lst) {
		searchResultModel.setRowCount(0);
		for(int i = 0; i < lst.size(); i++) {
			Slide31_DataVO vo = lst.get(i);
			Object[] data = {vo.getRoom_code(), vo.getTitle(), vo.getAddr(),
					vo.getReserv_start(), vo.getReserv_finish(), vo.getCost()};
			searchResultModel.addRow(data);
		}
	}
	
	public void actionPerformed(ActionEvent ae) {	// 액션이벤트
		if(ae.getActionCommand().equals("조회")) {	
			memberSearch();
		}else if(ae.getActionCommand().equals("◀이전페이지")) {	// 이전페이지 눌렀을때
			setVisible(false);
			try{Thread.sleep(3000);}catch(Exception e) {}	// 일단 작동 확인용으로 다시 보이게 했음
			setVisible(true);
		}else if(ae.getSource() == searchTextField && !searchTextField.getText().equals("")) {
			memberSearch();				// 엔터키 눌렀을때 검색
		}
	}	


}
